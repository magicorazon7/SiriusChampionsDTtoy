#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
repeat
------

Пакет repeat предназначен для взаимодействия пользовательской Python программы 
с расчётной моделью REPEAT VISION для решения следующих задач:
  
   - Анализ данных и выполнение постобработки временных рядов, полученных из
     REPEAT VISION;
   - Выполнение исследований на результатах расчётов модели REPEAT VISION;  
   - Выполнение параметрических исследований с возможностью передачи значений
     переменных в модель REPEAT VISION из вашей Python программы;
   - Решение задач оптимизации и аппроксимации с использованием внешних Python 
     модулей.

Ознакомьтесь с платформой REPEAT VISION на следующих ресурсах:

   - Общая информация о платформе https://repeatlab.ru/
   - Платформа REPEAT VISION https://app.repeat.vision/
   - Документация https://app.repeat.vision/docs/
   - Справка по Python пакету repeat
     https://app.repeat.vision/docs/reference/integrations/python/index.html 

Пример параметрических исследований
-----------------------------------

Для работы с примером вам необходима модель, созданная на платформе 
REPEAT VISION. Модель должна учитывать следующие требования:
  
   - Модель должна быть отлажена, в ней не должны содержаться ошибки запуска,
     модель должна успешно завершать расчёт;
   - Модель должна содержать глобальные переменные, связанные с необходимыми 
     вам блоками. Глобальные переменные модели REPEAT VISION предназначены для 
     получения из вашей Python программы новых значений свойств блоков модели
     и для получения новых значений граничных условий модели.

Примечание
~~~~~~~~~~

Для вашего удобства модель REPEAT VISION может содержать блок Выходной порт с 
целью применения Пользовательского названия параметра блока в Python коде для 
получения результатов расчёта. Ознакомиться с описанием блока можно в справке 
платформы REPEAT VISION
https://app.repeat.vision/docs/reference/blocklib/externalModels/OutPort/index.html

Начало использования примера в IDE JupyterLite
----------------------------------------------

Если используется IDE JupyterLite, то сначала необходимо выполнить установку repeat.

%pip install repeat

Продолжение примера
-------------------

Далее в Python программе загружаются следующие модули: 
  
   - repeat для взаимодействия с платформой REPEAT VISION;
   - repeat.parametric_study для параметрических исследований 
   - pandas и numpy для подготовки значений исходных данных и 
     обработки результатов расчётов.

>>> import pandas as pd
>>> import numpy as np
>>> import repeat as rp
>>> import repeat.parametric_study as ps

Создаётся экземпляр класса User с целью настройки токена пользователя 
REPEAT VISION. Для информации. Токен можно создать и скопировать в вашем личном 
кабинете по адресу https://app.repeat.vision/id/account/api-keys

>>> user = rp.User(token = 'уникальный токен из кабинета пользователя REPEAT VISION')
>>> app = rp.Application(user)

Примечание к процессу подключения к дистрибутиву REPEAT VISION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Для подключения к дистрибутиву REPEAT VISION, установленному по локальному 
адресу ``"https://my.repeat.vision.local"``, в котором публичный REST API 
расположен по пути ``"/api/v1/public"``, необходимо настроить аргументы address
и common_path следующим образом.

>>> app = rp.Application(
>>>     user,
>>>     address = "https://my.repeat.vision.local",
>>>     common_path = "/api/v1/public"
>>>     )

Далее создаётся экземпляр класса TimeInterval для настройки диапазона времени,
в котором пользователю необходимо получить значения результатов расчёта
параметров из модели REPEAT VISION:
  
   - Аргументу start передаётся начальное значение диапазона в миллисекундах 
     [мс],
   - Аргументу end передаётся конечное значение диапазона в [мс].

>>> t_interval = rp.TimeInterval(start = 1, end = 2050) 

Далее вам необходимо узнать идентификатор вашего проекта для параметрических 
исследований. В разделе управления проектами https://app.repeat.vision/projects
необходимо выбрать нужный вам проект в таблице, нажать на кнопку ... и  
в выпадающем меню нажать на кнопку Скопировать id проекта.
Значение скопированного id проекта присвойте переменной project.

>>> project = "21425d1a-70f9-4bke-8140-81bd312bd91b" 

На следующем шаге создаётся экземпляр класса ``ExplorationModel`` с настройками
для взаимодействия с вашей моделью для выполнения параметрических исследований.
Для этого вызывается метод ``get_exploration_model()``, которому в качестве 
аргументов передаётся значение идентификатора вашего проекта и настройки 
диапазона времени, в котором необходимо получить значения результатов расчёта.

>>> model = app.get_exploration_model(project, t_interval)

Далее требуется подготовить диапазон исходных данных для проведения 
параметрического исследования.

Необходимо создать словарь variable_values с глобальной переменной pressure, 
которая заранее должна быть настроена в вашей модели REPEAT VISION. Далее 
требуется создать декартово произведение для множества значений параметров с 
помощью функции ``get_cartesian_product()`` модуля ``repeat.parametric_study``.

>>> variable_values = dict(
>>>   pressure = np.linspace(1_000, 50_000, num = 5, dtype = np.float64)
>>>   )
>>> input_data = ps.get_cartesian_product(model, variable_values)


Также необходимо создать общую таблицу, пригодную для сохранения результатов 
расчёта и последующего выполнения анализа параметрических исследований.

>>> design_cases = input_data.copy(deep = True)
>>> # Значение из поля Пользовательское название блока Выходной порт 
>>> design_cases['flowrate'] = pd.NA 

Обратите внимание на колонку ``'flowrate'``. В вашей модели должен быть 
Выходной порт блок с Пользовательским названием flowrate. 
Если в вашей модели REPEAT VISION нет блока Выходной порт, то следует 
использовать идентификатор параметра, который можно скопировать из настроек 
блока вашей модели REPEAT VISION, например, ``'1713869940863_OUT_1'``.

Далее выполняется цикл параметрических исследований с учётом ранее созданных 
объектов исходных данных и результатов расчётов.

>>> for i, variables in input_data.iterrows():
>>>   with model as md:
>>>     md.run(variables)
>>>     design_cases.loc[i, 'flowrate'] = md.get_results('flowrate').iloc[-1]

Сначала выполняется цикл ``for i, variables in input_data.iterrows()`` 
по таблице исходных данных ``input_data``, где перебираются индексы ``i`` 
и значения переменных variables из метода iterrows класса DataFrame.

Далее, применяя менеджер контекста ``with model as md``, выполняется запуск 
модели на расчёт ``md.run(variables)`` с передачей актуальных значений 
переменных variables методу ``run()`` объекта ``md``.

Важно
-----

При взаимодействии вашей Python программы с моделью REPEAT VISION требуется 
применять контекстный менеджер класса ``ExplorationModel``, который гарантирует:
  
   - Безопасное завершение процесса расчёта модели REPEAT VISION;
   - Хранение результатов расчётов до следующей итерации запуска модели на 
     расчёт.


Также внутри менеджера контекста методом ``get_results()`` выполняется 
сохранение в таблицу design_cases одного актуального значения результата 
расчёта расхода ``'flowrate'`` на момент завершения времени моделирования.
Данное значение получается методом ``iloc[-1]`` из структуры ``pandas.Series``.

После успешного завершения цикла расчётов можно приступить к важному шагу
анализа результатов параметрических исследований. С помощью метода ``head()``
отображается табличное представление расчётных случаев, содержащих граничные 
условия по давлению ``'pressure'`` и результаты расчёта массового расхода 
``'flowrate'``.

>>> print(design_cases.head())

Анализ зависимости массового расхода ``'flowrate'`` от давления ``'pressure'`` 
удобнее выполнять с помощью графиков, доступных в методе ``plot()``.

>>> axis = design_cases.plot(x = 'pressure', y = 'flowrate')

Полный код примера
------------------

>>> import pandas as pd
>>> import numpy as np
>>> import repeat as rp
>>> import repeat.parametric_study as ps
>>>
>>>
>>> user = rp.User(token = 'уникальный токен из кабинета пользователя REPEAT VISION')
>>> app = rp.Application(user)
>>> t_interval = rp.TimeInterval(start = 1, end = 2050) 
>>> project = "21425d1a-70f9-4bke-8140-81bd312bd91b"
>>> model = app.get_exploration_model(project, t_interval)
>>> variable_values = dict(
>>>   pressure = np.linspace(1_000, 50_000, num = 5, dtype = np.float64)
>>>   )
>>> input_data = ps.get_cartesian_product(model, variable_values)
>>> design_cases = input_data.copy(deep = True)
>>> design_cases['flowrate'] = pd.NA 
>>> for i, variables in input_data.iterrows():
>>>   with model as md:
>>>     md.run(variables)
>>>     design_cases.loc[i, 'flowrate'] = md.get_results('flowrate').iloc[-1]
>>> 
>>> print(design_cases.head())
>>> axis = design_cases.plot(x = 'pressure', y = 'flowrate')

Ограничения и зависимости
-------------------------

Требуется язык программирования Python версии 3.11 и выше.
Требуется наличие следующих модулей:
  
   - requests
   - pydantic версия 1
   - pandas 
   - matplotlib
   - scipy

"""

__version__ = (
  1, 3, 2
  )
from . import data_structures
from . import messages
from . import errors
from . import validators
from . import repeat_connection
from . import repeat_model
from . import parametric_study
from .repeat_user import User
from .repeat_model import Application, Model, ExplorationModel
from .data_structures import Parameter, TimeInterval
import warnings
from requests.packages import urllib3
# Отключаются предупреждения непроверенных HTTPS запросов
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
