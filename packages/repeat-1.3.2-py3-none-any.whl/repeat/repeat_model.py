#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Модуль взаимодействия с REPEAT VISION
"""
from dataclasses import dataclass, field
from datetime import timedelta
import enum
import math
import time as tm
from timeit import default_timer as timer
import warnings
import requests
from requests.exceptions import HTTPError
import pandas as pd
from . import errors as err
import repeat.validators as vld
from .repeat_connection import APIKeyAuth
from .repeat_user import User, _UserEndpoints
from .data_structures import Parameter, TimeInterval
from .repeat_requests import get_results

def check_parameter_exist(parameter_id : str, block_id : str, parameters : dict,
                          custom_named_result_ids : dict = None):
  """
  Функция проверки наличия запрашиваемого параметра

  Parameters
  ----------
  parameter_id : str
    Идентификатор параметра модели REPEAT VISION.
  block_id : str
    Идентификатор блока модели REPEAT VISION.
  parameters : dict
    Словарь с параметрами для проверки наличия запрашиваемого имени name 
    параметра.
  custom_named_result_ids : dict
   Словарь, в котором ключами являются пользовательские названия параметров, 
   ранее присвоенные пользователем в модели REPEAT VISION, например, блокам out. 
   По умолчанию None.

  Raises
  ------
  REPEATParameterNotExistError
    Ошибка, объявляемая, если параметр name отсутствует в словаре parameters.

  Returns
  -------
  None.

  """
  msg_allowed_custom_named_results = (
    vld._get_message_allowed_custom_named_results(
      custom_named_result_ids
      )
    )
  if block_id not in parameters:
    raise err.REPEATParameterNotExistError(
      f"Параметр с имененем {parameter_id = } отсутствует в модели "
      "REPEAT VISION\n"
      "Проверьте, пожалуйста, имя параметра\n"
      f"{msg_allowed_custom_named_results}"
      )
  
  if parameter_id not in parameters[block_id]:
    raise err.REPEATParameterNotExistError(
      f"Параметр с имененем {parameter_id = } отсутствует в модели "
      "REPEAT VISION\n"
      "Проверьте, пожалуйста, имя параметра\n"
      f"{msg_allowed_custom_named_results}"
      )

@dataclass
class Solver:
  """
  Класс для настройки соединения с расчётным модулем REPEAT VISION с целью 
  получения результатов расчёта модели

  Parameters
  ----------
  address : str
    Адрес расчётного модуля, выполняющего моделирование
  port : str
    Порт расчётного модуля
  type : str
    Тип расчётного модуля
  user_id : str
    Идентификатор пользователя, который запустил расчёт
  project_id : str
    Идентификатор проекта REPEAT VISION, который рассчитывается модулем
  url : str   
    Адрес платформы REPEAT VISION. Обычно 'https://app.repeat.vision'
  common_path : str
    Общая часть пути к методам. Значение по умолчанию 
    ``'/backend/api/v1/public'``
  """
  address : str = field(repr = False)
  port : str = field(repr = False)
  type : str
  user_id : str
  project_id : str
  url : str
  common_path : str = "/backend/api/v1/public"
  
  def __post_init__(self):
    self.get_all = (self.url +
       self.common_path + '/model/parameters/getAll')
    self.get_range = (self.url +
       self.common_path + '/model/parameters/getRange')

  def to_header_request(self):
    return {'addressVM' : f'{self.address}:{self.port}'}

def get_solver_address(application_url : str, auth : APIKeyAuth, 
                       common_path : str = "/backend/api/v1/public") -> Solver:
  """
  Функция для подготовки данных о расчётном модуле REPEAT VISION, который в 
  момент вызова функции должен быть запущен по одному из следующих вариантов:
    
    - Из интерфейса приложения REPEAT VISION для расчёта модели кнопкой RUN
    - Вызовом метода .run() экземпляра класса :py:class:`ExplorationModel`
    - Из web API запросом POST https://app.repeat.vision/backend/api/v1/public/model/run

  Parameters
  ----------
  application_url : str
    Адрес сайта программы REPEAT VISION. Подробное описание смотри в справке 
    класса Application.
  auth : APIKeyAuth
    Экземпляр класса :py:class:`repeat.repeat_connection.APIKeyAuth` для 
    aвторизации во время запросов модулем requests.
  common_path : str
    Общая часть пути к методам. Значение по умолчанию 
    ``'/backend/api/v1/public'``

  Returns
  -------
  Solver
    Экземпляр класса Solver с описанием настроек соединения с расчётным модулем 
    REPEAT VISION.

  """
  solver_request_url = (
    f'{application_url}{common_path}/controllervm/getUserVM'
    )
  try:
    response = requests.get(
      solver_request_url,
      verify=False,
      auth = auth,
      )
    response.raise_for_status()
    
  except HTTPError as http_error:
    err.handle_user_error_codes(http_error)
    
  else:
    solver_description = response.json()
    solver = Solver(
      address = solver_description['addr'],
      port = solver_description['portSolver'],
      type = solver_description['solverType'],
      user_id = solver_description['userId'],
      project_id  = solver_description['projectId'],
      url = application_url,
      common_path = common_path
      )
    
    return solver

@dataclass
class _ApplicationEndpoints:
  """
  Вспомогательный класс аттрибутов с адресами WEB API для взаимодействия 
  с моделью REPEAT VISION
  
  Parameters
  ----------
  address : str
    Адрес сайта программы REPEAT VISION. Подробное описание смотри в справке 
    класса Application.
  auth : APIKeyAuth
    Экземпляр класса :py:class:`repeat.repeat_connection.APIKeyAuth` 
    для aвторизации во время запросов модулем requests.
  common_path : str
    Общая часть пути к методам. Значение по умолчанию 
    ``'/backend/api/v1/public'``

  Attributes
  ----------
  log : str
    address + common_path + /model/status 
    Метод GET для получения журнала.
  solvers_state
    address + common_path + /controllervm/status
    Метод GET для получения информации о количестве расчётных модулей.
  projects : str
    address + common_path + /project/getAll  
    Метод GET получения списка проектов пользователя.
  release_model : str
    address + common_path + /model/stop
    Метод POST для остановки расчёта с очисткой результатов расчёта на стороне 
    расчётного модуля и с завершением работы расчётного модуля.
  resume : str
    address + common_path + /model/continue
    Метод PUT для продолжения расчёта модели после ранее выполненной остановки.
  run : str
    address + common_path + /model/run
    Метод POST для запуска расчёта. 
    Начиная с версии пакета repeat 0.9.0 метод содержит новые поля для настройки 
    Времени моделирования (секунды) и Шага интегрирования (миллисекунды).
  status : str
    address + common_path + /model/statusModel
    Метод GET для получения статуса модели.
  stop : str
    address + common_path + /model/softStop
    Метод POST для остановки расчёта с возможностью выгрузки результатов расчёта.
  variables : str
    address + common_path + /model/globals
    Метод GET для получения глобальных переменных модели.
    
  Returns
  -------
  None  
  """
  address : str
  auth : APIKeyAuth
  common_path : str = "/backend/api/v1/public"
  
  def __post_init__(self):
    # адрес web api post для запуска расчёта 
    self.run = (self.address +
       self.common_path + '/model/run')
    # адрес web api post для остановки расчёта 
    # с возможностью выгрузки результатов расчёта
    self.stop = (self.address +
      self.common_path + '/model/softStop')
    # адрес web api post для остановки расчёта 
    # с очисткой результатов расчёта на стороне расчётного модуля и 
    # с завершением работы расчётного модуля
    self.release_model = (self.address +
       self.common_path + '/model/stop')
    # адрес web api put для продолжения расчёта модели после ранее выполненной
    # остановки
    self.resume = (self.address +
       self.common_path + '/model/continue')
    # адрес web api get для получения глобальных переменных модели
    self.variables = (self.address +
       self.common_path + '/model/globals')
    # адрес web api get для получения статуса модели
    self.status = (self.address +
       self.common_path + '/model/statusModel')
    # адрес web api get для получения журнала
    self.log = (self.address +
      self.common_path + '/model/status')
    # адрес web api get для получения информации о количестве расчётных модулей.
    self.solvers_state = (self.address +
      self.common_path + '/controllervm/status')
    # адрес web api get для получения набора проектов
    self.projects = (self.address +
      self.common_path + '/project/getAll')

class SolvingStatus(enum.IntEnum):
  """
  Состояния расчётного процесса модели REPEAT VISION

  Attributes
  ----------
  IN_PROGRESS : int
    Расчёт в процессе. Значение 1  
  COMPLETE : int
    Расчёт успешно завершён по времени моделирования, установленного в проекте.
    Значение 21
  STOP_BY_CONDITION : int
    Расчёт успешно завершён по условию (приказ блока STOP и т.д.). Значение 0  
  STOP_BY_USER : int
    Расчёт остановлен пользователем из графического интерфейса. Значение 2
  PAUSED : int
    Расчёт остановлен блоком PAUSE. Значение 3   
  MODEL_NOT_FOUND : int
    Не удалось запустить расчёт. Проект не найден расчётным модулем. Значение 20 
  EXCEEDED_RAM_LIMIT : int
    Расчёт не завершён из-за ограничения оперативной памяти. Значение 51   
  EXCEEDED_STORAGE_LIMIT : int
    Расчёт не завершён из-за ограничений памяти. Значение 52 
  ERROR : int
    Возникла ошибка в процессе расчёта. Значение 100 
  """
  # Расчёт в процессе
  IN_PROGRESS = 1 
  # Расчёт успешно завершён по времени моделирования, установленного в проекте
  COMPLETE = 21
  # Расчёт успешно завершён по условию (приказ блока STOP и т.д.)
  STOP_BY_CONDITION = 0
  # Расчёт остановлен пользователем из графического интерфейса
  STOP_BY_USER = 2
  # Расчёт остановлен блоком PAUSE
  PAUSED = 3
  # Не удалось запустить расчёт. Проект не найден расчётным модулем
  MODEL_NOT_FOUND = 20
  # Расчёт не завершён из-за ограничения оперативной памяти
  EXCEEDED_RAM_LIMIT = 51
  # Расчёт не завершён из-за ограничений памяти
  EXCEEDED_STORAGE_LIMIT = 52
  # Возникла ошибка в процессе расчёта
  ERROR = 100

def _get_custom_named_result_ids(blocks : dict) -> dict:
  """
  Функция возвращает словарь с параметрами результатов, содержащих
  пользовательские названия с целью удобного взаимодействия между методом 
  получения результатов модели  :py:meth:`ExplorationModel.get_results()` 
  и моделью REPEAT VISION
  
  Notes
  -----  
  Реализация функции позволяет обрабатывать только блоки **Выходной порт** 
  из библиотеки **Внешние модели**

  Parameters
  ----------
  blocks : dict
    Словарь с описанием всех блоков модели REPEAT VISION.

  Raises
  ------ 
  REPEATModelError
    В случае пустого словаря blocks с информацией о блоках модели REPEAT VISION 

  Returns
  -------
  dict
    Словарь, в котором ключами являются пользовательские названия параметров, 
    ранее присвоенные пользователем в модели REPEAT VISION, например, блокам out. 
    Значениями словаря являются словари с двумя обязательными ключами:
    1. 'parameter_id' со строковым значением идентификатора параметра, 
    2. 'block_id' со строковым значением идентификатора блока. 
    Данные объекты предназначены для дальнейшего получения результатов 
    с использованием параметров, содержащих пользовательские названия.
  
  """
  if not blocks:
    raise err.REPEATModelError(
      "Пустой словарь блоков\n"
      "Для работы модуля требуется наличие блоков в модели"
      )
  name_key = 'customName'
  def is_custom_named_block(block, criteria_key):
    return criteria_key in block

  custom_named_blocks = {
    name : block for name, block in blocks.items() 
    if is_custom_named_block(block, name_key)
    }
  if not custom_named_blocks:
    # Если в схеме отсутствуют блоки out, то пользователь должен 
    # вручную копировать из Приложения REPEAT VISION id параметров для 
    # результатов расчётов
    return {} 

  # Выводятся только параметры результатов для out блоков
  out_block_result_ids = {
    block[name_key] : {
      'parameter_id' : block['params'][0]['modelName'],
      # Backend выдаёт строковое значение идентификатора блока в виде его 
      # номера или uuid. Значения символов от backend могут быть как строчными,
      # так и заглавными. Для единообразия и соответствия block_id с parameter_id 
      # принято решение все id приводить к заглавным символам.
      'block_id' : name.upper(), 
      }
    for name, block in custom_named_blocks.items()
    }
  return out_block_result_ids

@dataclass
class ExplorationModel:
  """
  Класс для взаимодействия с моделью REPEAT VISION.
  
  Класс обеспечивает:
    
  * Передачу исходных данных в модель через глобальные переменные модели 
    REPEAT VISION
  * Запуск модели на расчёт
  * Получение результатов расчётов из блоков **Выходной порт** 
    библиотеки **Внешние модели**
  * Получение необходимой информации о модели и о процессе расчёта

  Notes
  -----
  Для обеспечения взаимодействия Python программы с моделью REPEAT VISION 
  требуется наличие глобальных переменных в модели, связанных с необходимыми 
  вам свойствами блоков. 
  В глобальные переменные модели REPEAT VISION записываются значения параметров
  и граничных условий от вашей Python программы с помощью экземпляра класса 
  ExplorationModel.
  
  Parameters
  ----------
  project : str | int
    Идентификатор проекта. Номер проекта доступен в модуле repeat через атрибут 
    ``projects`` в экземпляре класса :py:class:`Application`.
    
    .. hint::
      
      Номер проекта доступен в приложении REPEAT VISION на странице управления 
      проектами https://app.repeat.vision/projects Также номер проекта доступен 
      после открытия (для редактирования или запуска) в настройках проекта 
      в поле id.
  
  name : str
    Имя проекта с моделью REPEAT VISION
  time_interval : :py:class:`repeat.data_structures.TimeInterval` 
    Экземпляр класса для описания интервала времени. Значение по умолчанию None.
  endpoints : _ApplicationEndpoints
    Экземпляр класса с атрибутами WEB API REPEAT VISION
  solver_retry_delay : float | int
    Длительность секунд для одной задержки расчёта. Значение по умолчанию 
    :math:`0.25 [cек]`. Данный параметр, а также аргумент ``max_retries_number`` 
    необходимы на следующие случаи:
    
    * Количество пользователей, которые выполняют запуск моделей на расчёт
      превышает доступное количество расчётных модулей. Тогда в расчётных 
      циклах допускается время на ожидание свободного расчётного модуля;
    * Выполнение параметрических исследований, решения задач оптимизации или
      выполнение расчётных циклов в дистрибутиве платформы REPEAT VISION в 
      локальной сети предприятия с ограниченным количеством доступных расчётных 
      модулей. Тогда возможен случай начала расчётного цикла при отсутствии 
      хотя бы одного доступного расчётного модуля.
    
    .. versionadded:: 1.1.0
  
  max_retries_number : int
    Количество попыток задержки расчёта. Если значение больше нуля, то 
    выполняется проверка наличия свободного расчётного модуля перед выполнением
    расчёта методом ``.run()``. Значение по умолчанию 0.
    
    .. versionadded:: 1.1.0

  Returns
  -------
  None
  
  Attributes
  ----------
  custom_named_result_ids : dict
    Словарь с параметрами результатов, содержащих пользовательские названия,
    блоков **Выходной порт** из библиотеки **Внешние модели**. Словарь доступен
    после запуска расчёта модели методом ``.run()``
  parameters : dict
    Словарь с параметрами модели. Ключ : str словаря parameters - идентификаторы
    блоков модели REPEAT VISION. Значение : dict словаря parameters - набор 
    параметров блока. Словарь parameters доступен после запуска расчёта модели 
    методом ``.run()``

  Examples
  --------
  >>> import pandas as pd
  >>> from repeat import User, Application, TimeInterval
  >>>  
  >>> user = User(token = 'уникальный токен из кабинета пользователя REPEAT VISION')
  >>> app = Application(user)
  >>> t_interval = TimeInterval(start = 1, end = 2500)
  >>> project = "21425d1a-70f9-4bke-8140-81bd312bd91b"
  >>> model = app.get_exploration_model(project, t_interval)  
  >>> variables = pd.Series({'pressure' : 85000}, dtype = float)
  >>> with model as md:
  >>>     md.run(variables)
  >>>     results = md.get_results('flowrate')
  """
  project : str | int
  name : str
  time_interval : TimeInterval
  endpoints : _ApplicationEndpoints = field(repr = False)
  solver_retry_delay : float = 0.25
  max_retries_number : int = 0

  def __post_init__(self):
    # Имена глобальных переменных модели REPEAT VISION для последующей 
    # валидации новых переменных, создаваемых пользователем
    self._validate_time_interval(self.time_interval)
    self.existing_variables_names = set(self.existing_variables.index)

  def _is_available_solvers(self) -> bool:
    """
    Функция возвращает логическое значение наличия доступных расчётных модулей.

    Returns
    -------
    bool
      Логическое значение наличия доступных расчётных модулей:
        
        * ``True`` - Есть доступные расчётные модули;
        * ``False`` - Все расчётные модули заняты.
    """
    try:
      response = requests.get(
          self.endpoints.solvers_state, 
          auth = self.endpoints.auth,
          verify = False,
          )
      response.raise_for_status()
      
    except HTTPError as error:
      err.handle_unknown_errors(
        error,
        'на этапе запроса информации о количестве расчётных модулей'
                                )
    else:
      status = response.json()
      
      return status["isAvailableSolvers"]
    
  def _wait_free_solver(self, retry_delay : float, max_retries_number : int):
    """
    Функция задерживает выполнение расчёта на заданной количество повторов.
    
    Warning
    -------
    Функция должна использоваться только при max_retries_number > 0

    Parameters
    ----------
    retry_delay : float
      Длительность секунд для одной задержки расчёта.
    max_retries_number : int
      Количество попыток задержки расчёта.

    Raises
    ------
    REPEATSolverInitError
      Вызывается исключение в случае, если от платформы REPEAT VISION не удалось
      дождаться свободного расчётного модуля.

    Returns
    -------
    None.
    """
    for i in range(max_retries_number):
      if not self._is_available_solvers():
        tm.sleep(retry_delay)
      
      else:
        break
    
    else:
      raise err.REPEATSolverInitError(
        "Не удалось дождаться свободного расчётного модуля.\n"
        "Необходимо освободить расчётный модуль для вашей модели\n"
        "или изменить настройки ожидания расчётного модуля.\n"
        f"Количество попыток {max_retries_number};\n"
        f"Задержка на каждой попытке {retry_delay} [сек].\n"
        )

  def _initialize_solver(self, variables : pd.Series, 
                         real_time_sync : bool, modeling_time : int, 
                         integration_step : int, discretization_step : int):
    vld.validate_variables_names(
      input_names = set(variables.index), 
      existing_names = self.existing_variables_names
      )
    self._validate_real_time_sync(real_time_sync)
    input_data = {
      'globalVariables' : variables.apply(str).to_dict(),
      'isRealTimeSync' : real_time_sync,
      }
    
    skip_time_preferences = (
      modeling_time is None and 
      integration_step is None and 
      discretization_step is None
      )
    if not skip_time_preferences:
      self._validate_time_settings(
        real_time_sync, modeling_time, integration_step, discretization_step
        )
      time_preferences = {
        'modellingTime': str(modeling_time),
        'integrationStep': str(integration_step),
        'discretizationStep': str(discretization_step),
        }
      input_data.update(time_preferences)
    
    try:
      response = requests.post(
        self.endpoints.run, 
        auth = self.endpoints.auth,
        verify = False,
        json = {'header' : input_data},
        headers = self.project_to_repeat(),
        )
      response.raise_for_status()
      
    except HTTPError as error:
      err.handle_initialize_solver_errors(error)
    
    else:
      data = response.json()
      self._elements = data
      return _get_custom_named_result_ids(data['elements'])

  def run(self, variables : pd.Series, real_time_sync : bool = False, 
          modeling_time : int = None, integration_step : int = None, 
          discretization_step : int = None):
    """
    Метод запуска на расчёт модели REPEAT VISION с передачей в модель исходных
    данных. В модель возможно передать значения исходных данных для глобальных
    переменных, заранее настроенных в модели REPEAT VISION.

    Notes
    -----
    Если необходимо использовать настройки времени моделирования, шага 
    интегрирования или шага времени между ближайшими занесениями 
    результатов расчёта в базу данных, тогда в метод ``.run()`` требуется 
    передавать значения трём **обязательным** аргументам: modeling_time, 
    integration_step и discretization_step. 
    В ином случае значения аргументов modeling_time, integration_step и 
    discretization_step используются из ранее сохранённой модели REPEAT VISION 
    (смотрите пример).

    Parameters
    ----------
    variables : pd.Series
      Значения глобальных переменных модели REPEAT VISION. Переменные 
      формируются в структуре данных pandas.Series, в которой ``index`` должны 
      содержать названия глобальных переменных с типом ``str``, тип данных 
      у значений переменных должен быть ``dtype = float``. Например, 
      ``variables = pd.Series(data = [25], index = ['Temperature'],dtype = float)``
    real_time_sync : bool
      Синхронизация с реальным временем. По умолчанию синхронизация выключена, 
      значение False. При выключенной синхронизации вычисление будет 
      производиться с максимально возможной скоростью и обычно опережает 
      реальное время.
      При включенной синхронизации один шаг модельного времени будет 
      ориентировочно соответствовать одному шагу реального времени. При большом 
      объёме вычислений модельное время может отставать от реального.
      
      .. versionadded:: 0.9.0
      
    modeling_time : int
      Значение времени моделирования (секунды), после которого расчёт будет 
      остановлен. По умолчанию значение None, используется настройка модели, 
      заданная через графическое приложение REPEAT VISION.
      
      .. versionadded:: 0.9.0
      
    integration_step : int
      Значение шага интегрирования (миллисекунды) между соседними 
      рассчитываемыми состояниями модели. По умолчанию значение None, 
      используется настройка модели, заданная через графическое приложение 
      REPEAT VISION.
      
      .. versionadded:: 0.9.0
      
    discretization_step : int
      Значение шага времени (миллисекунды) между ближайшими занесениями 
      результатов расчёта в базу данных. По умолчанию значение None, 
      используется настройка модели, заданная через графическое приложение 
      REPEAT VISION.
      
      .. versionadded:: 0.9.0
      
    
    Returns
    -------
    None.
    
    Examples
    --------
    >>> import pandas as pd
    >>> from repeat import User, Application, TimeInterval
    >>>  
    >>> user = User(token = 'уникальный токен из кабинета пользователя REPEAT VISION')
    >>> app = Application(user)
    >>> t_interval = TimeInterval(start = 1, end = 2500)
    >>> project = "21425d1a-70f9-4bke-8140-81bd312bd91b"
    >>> model = app.get_exploration_model(project, t_interval)  
    >>> variables = pd.Series({'pressure' : 85000}, dtype = float)
    >>> with model as md:
    >>>     md.run(variables, 
    >>>            real_time_sync = False, # Синхронизация выключена
    >>>            modeling_time = 2.5, # Секунды
    >>>            integration_step = 100, # Миллисекунды
    >>>            discretization_step = 100, # Миллисекунды
    >>>            )
    >>>     results = md.get_results('flowrate')
    >>> 
    >>> # Настройки времени modeling_time и шагов integration_step и 
    >>> # discretization_step используются из модели, ранее сохранённой в 
    >>> # приложении REPEAT VISION
    >>> with model as md:
    >>>     md.run(variables) 
    >>>     results = md.get_results('flowrate')
    """
    if self.max_retries_number:
      self._wait_free_solver(self.solver_retry_delay, self.max_retries_number)
    
    self.custom_named_result_ids = self._initialize_solver(
      variables,
      real_time_sync,
      modeling_time,
      integration_step,
      discretization_step,
      )
    self.solver = get_solver_address(
      self.endpoints.address, self.endpoints.auth, self.endpoints.common_path
      )
    self.parameters = self.get_all_parameters()
    start = timer()
    while True:
      match self.status:
        case SolvingStatus.IN_PROGRESS:
          tm.sleep(1)
          continue
        
        case SolvingStatus.COMPLETE | SolvingStatus.STOP_BY_CONDITION: 
          break
    
    end = timer()
    delta = timedelta(seconds = end - start)
    print(f'Время расчёта {delta}')

  def get_results(self, name : str, time_interval : TimeInterval = None
                  ) -> pd.Series:
    """
    Метод получения результатов расчёта 

    Notes
    -----
    Результаты расчёта доступны сразу после успешного выполнения первых 
    итераций расчёта в процессе моделирования после запуска модели методом 
    :py:meth:`run`. Метод :py:meth:`release_model()` очищает результаты расчёта 
    и завершает работу расчётного модуля.

    Parameters
    ----------
    name : str
      Имя параметра, для которого требуются результаты расчёта. 
      
      .. tip::
        
        В модели REPEAT VISION рекомендуется использовать блоки **Выходной порт** 
        библиотеки **Внешние модели** с целью получения результатов расчёта по
        именам параметров. В блоке **Выходной порт** в поле 
        **Пользовательское название** требуется указать имя параметра. 
        Также допускается использовать для имён параметров id параметров из 
        свойств блоков модели REPEAT VISION.
      
    time_interval : :py:class:`repeat.data_structures.TimeInterval` 
      Экземпляр класса для описания интервала времени. 
      Значение по умолчанию None на случай если time_interval создан в
      при инициализации экземпляра класса ExplorationModel и если для всех 
      параметров результатов достаточно общей настройки интервала времени.
      Используйте новый экземпляр класса TimeInterval в качестве аргумента
      time_interval к методу ``get_results()`` в случае, если для каждого
      параметра результата нужен собственный интервал времени.
      
      .. important::
        
        Если аргумент time_interval отличен от ``None`` в методе 
        ``get_results()``, то при создании временного ряда результата расчёта 
        time_interval используется в приоритетном порядке вместо аттрибута
        экземпляра класса ExplorationModel (Обратите внимание на примеры ниже).
        
      .. versionadded:: 0.9.0
      
    
    Returns
    -------
    results : pandas.Series
      Результаты расчёта в виде временного ряда для заранее настроенного 
      time_interval.
      Атрибут name в pandas.Series будет обладать значением в соответствии с
      именем параметра, указанного в качестве аргумента метода 
      ``get_results(name : str)``
    
    Examples
    --------
    >>> import pandas as pd
    >>> from repeat import User, Application, TimeInterval
    >>>  
    >>> user = User(token = 'уникальный токен из кабинета пользователя REPEAT VISION')
    >>> app = Application(user)
    >>> model = app.get_exploration_model(
    >>>     project = "21425d1a-70f9-4bke-8140-81bd312bd91b"
    >>>     )
    >>> variables = pd.Series({'pressure' : 85000}, dtype = float)
    >>> with model as md:
    >>>     md.run(variables, 
    >>>            real_time_sync = False, # Синхронизация выключена
    >>>            modeling_time = 2.5, # Секунды
    >>>            integration_step = 100, # Миллисекунды
    >>>            discretization_step = 100, # Миллисекунды
    >>>            )
    >>>     flow = md.get_results('flowrate',
    >>>                           TimeInterval(start = 1, end = 2500)
    >>>                            )
    >>>     temp = md.get_results('temprature',
    >>>                           TimeInterval(start = 2450, end = 2500)
    >>>                            )
    >>> 
    >>> pipe_model = app.get_exploration_model(
    >>>     project = "21425d1a-70f9-4bke-8140-81bd312bd91b", 
    >>>     # Общий интервал времени
    >>>     time_interval = TimeInterval(start = 1, end = 1000) 
    >>>     )
    >>> pipe_vars = pd.Series({'inner_diameter' : 0.2})
    >>> with pipe_model as md:
    >>>     md.run(pipe_vars)
    >>>     # Расчётные значения расхода и давления необходимы для одинакового
    >>>     # интервала всего времени моделирования
    >>>     flow = md.get_results('flowrate')  
    >>>     press = md.get_results('pressure')
    >>>     # Температура нужна только для интервала времени при завершении 
    >>>     # моделирования
    >>>     temp = md.get_results('temprature',
    >>>                           TimeInterval(start = 950, end = 1000)
    >>>                           )
    """
    self._validate_time_interval(time_interval)
    match (time_interval, self.time_interval):
      case (None, None):
        raise err.REPEATError(
          "Необходимо назначение настройки интервала времени с помощью "
          "экземпляр класса TimeInterval.\n"
          "Используйте настройку интервала времени одним из следующих способов:\n"
          "   - При вызове метода get_exploration_model() для создания нового "
          "экземпляра класса ExplorationModel;\n"
          "   - При вызове метода get_results() у ранее созданного экземпляра "
          "класса ExplorationModel."
          )      
      case (None, value):
        select_time_interval = value
      
      case (value, _):
        select_time_interval = value
    
    if self.status not in (SolvingStatus.COMPLETE, 
                           SolvingStatus.STOP_BY_CONDITION):
      raise err.REPEATResultsNotExistError(
        "Результаты расчёта возможно получить после успешного завершения "
        "процесса расчёта.\n"
        "Запустите модель REPEAT VISION на расчёт методом .run() с аргументом "
        "значений глобальных переменных модели"
        )
    
    is_custom_name = name in self.custom_named_result_ids
    if is_custom_name:
      # Имя параметра заранее присвоено в поле Пользовательское название 
      # для out блока id параметра берётся из соответствующего словаря
      # В данном случае допускаются параметры следующих видов:
      #   - "D664D9B0-E1EE-434B-BA15-9D418AC7AD61_OUT_3"
      #   - "1719203162182_OUT_2"
      parameter = self.custom_named_result_ids[name]
      
    else:
      # Допускается копирование id параметра из интерфейса блока для остальных
      # блоков, но для данного случая необходима проверка id параметра
      # В данном случае допускается параметр только вида "1719203162182_OUT_2"
      parameter = {
        'parameter_id' : name,
        'block_id' : name.split("_")[0],
        }
      vld.validate_parameter_name_structure(name, self.custom_named_result_ids)
      check_parameter_exist(
        **parameter,
        parameters = self.parameters, 
        custom_named_result_ids = self.custom_named_result_ids
        ) 
    
    param = Parameter(name = parameter['parameter_id'], 
                      time_interval = select_time_interval)
    results = get_results(param, self.endpoints.auth, self.solver)
    if is_custom_name:
      results.name = name
    
    return results
  
  def release_model(self):
    """
    Метод завершения работы с моделью.
    Останавливается расчёт, очищаются результаты расчёта и завершается работа
    расчётного модуля.
    
    Notes
    -----
    
    Метод ``.release_model()`` используется при работе с классом ExplorationModel
    при помощи контекстного менеджера ``with``. При этом подходе обеспечивается:
    
    - Безопасное завершение процесса расчёта модели REPEAT VISION
    - Возможность задания новых значений переменных модели при следующем 
      запуске модели методом :py:meth:`run`.

    Returns
    -------
    None.

    """
    try:
      response = requests.post(
        self.endpoints.release_model, 
        auth = self.endpoints.auth,
        verify = False,
        headers = self.project_to_repeat(),
        )
      response.raise_for_status()
      
    except HTTPError as http_error:
      # TODO Добавить обработку ошибок для метода run
      err.handle_unknown_errors(
        http_error,
        'на этапе завершения работы с моделью'
        )

  def stop(self):
    """
    Метод остановки расчёта с возможностью выгрузки результатов расчёта

    Returns
    -------
    None.

    """
    try:
      response = requests.post(
        self.endpoints.stop, 
        auth = self.endpoints.auth,
        verify = False,
        headers = self.project_to_repeat(),
        )
      response.raise_for_status()
      
    except HTTPError as http_error:
      # TODO Добавить обработку ошибок для метода
      err.handle_unknown_errors(
        http_error,
        "на этапе остановки модели"
        )

  def __enter__(self):
    return self
  
  def __exit__(self, exc_type, exc_value, exc_tb):
    self.release_model()

  @property
  def status(self) -> SolvingStatus:
    """
    Атрибут состояния процесса расчёта модели

    Raises
    ------
    REPEATSolverNotRunError
      В случае необходимости запуска или перезапуска расчёта.
    REPEATSolverError
      В случае неизвестного кода ошибки, а также при превышении лимитов
      на оперативную память или память постоянного хранения модели.
    NotImplementedError
      Нет реализации работы модуля repeat для модели, содержащей блоки PAUSE 
      или STOP.

    Returns
    -------
    model_status : SolvingStatus
      Код состояния модели, в соответствии с описанием класса :py:class:`SolvingStatus`:
      модель в процессе расчёта или расчёт успешно завершён. После успешного 
      завершения расчёта допускается получение результата расчёта.

    """
    try:
      response = requests.get(
        self.endpoints.status,
        auth = self.endpoints.auth,
        verify = False,
        headers = self.project_to_repeat(),  
        )
      response.raise_for_status()
      
    except HTTPError as error:
      err.handle_model_status_errors(error)
      
    else:
      model_status = int(response.json()['statusModel'])
      match model_status:
        case (SolvingStatus.IN_PROGRESS | SolvingStatus.COMPLETE | 
              SolvingStatus.STOP_BY_CONDITION):
          return SolvingStatus(model_status)          
  
        case SolvingStatus.STOP_BY_USER:
          raise NotImplementedError(
            "Расчёт остановлен пользователем из графического интерфейса.\n"
            "Данное поведение не обрабатывается при работе модуля repeat"
            )          
        case SolvingStatus.PAUSED:
          raise NotImplementedError(
            "Расчёт остановлен блоком PAUSE.\n"
            "Данное поведение не обрабатывается при работе модуля repeat"
            )             
        case SolvingStatus.MODEL_NOT_FOUND:
          raise err.REPEATSolverInitError(
            "Не удалось запустить расчёт. Проект не найден расчётным модулем\n"
            "Перезапустите расчёт"
            )
        case SolvingStatus.EXCEEDED_RAM_LIMIT:
          raise err.REPEATSolverError(
            "Расчёт не завершён из-за ограничения оперативной памяти, "
            "доступной для модели.\n"
            "Попробуйте изменить настройки проекта, например:\n"
            "   * Шаг интегрирования\n"
            "   * Время моделирования"
            )
        case SolvingStatus.EXCEEDED_STORAGE_LIMIT:
          raise err.REPEATSolverError(
            "Расчёт не завершён из-за ограничений памяти, "
            "доступной для хранения модели"
            )
        case SolvingStatus.ERROR:
          raise err.REPEATSolverError(
            "Возникла ошибка в процессе расчёта.\n"
            "Ознакомьтесь с журналом, где приведено подробное описание ошибки.\n"
            "Попробуйте перезапустить расчёт.\n"
            "В случае повторения проблемы обратитесь за помощью в тех. поддержку"
            )
        case _:
          raise err.REPEATSolverError(
            "Возникла необработанная ошибка в процессе расчёта\n"
            f"Код ошибки {model_status = }\n"
            "Просим вас передать информацию в тех. поддержку"
            )            

  @property
  def existing_variables(self) -> pd.Series:
    """
    Атрибут значений глобальных переменных модели REPEAT VISION

    Raises
    ------
    REPEATHTTPError
      Ошибка, возникающая в случае невозможности получения значений переменных.
    REPEATVariableNotExistError
      Ошибка в случае отсутствия в модели глобальных переменных.
    
    Returns
    -------
    pandas.Series
      Имена глобальных переменных модели REPEAT VISION, а также текущие значения 
      переменных с типом float. Имена переменных записываются в атрибут index

    Examples
    --------
    >>> from repeat import User, Application, TimeInterval
    >>>  
    >>> user = User(token = 'уникальный токен из кабинета пользователя REPEAT VISION')
    >>> app = Application(user)
    >>> t_interval = TimeInterval(start = 1, end = 2500)
    >>> project = 1247
    >>> model = app.get_exploration_model(project, t_interval)  
    >>> print(model.existing_variables)
    >>> # pressure    70000.0
    >>> # dtype: float64
    """
    try:
      response = requests.get(
        self.endpoints.variables,
        auth = self.endpoints.auth,
        verify = False,
        headers = self.project_to_repeat(),  
        )
      response.raise_for_status()
      
    except HTTPError as error:
      # TODO Добавить обработку ошибок для метода existing_variables
      err.handle_unknown_errors(
        error,
        "на этапе получения данных о глобальных переменных модели REPEAT VISION"
        ) 
    
    else:
      data = response.json()
      self._validate_existing_variables(data)
      vld.validate_variables_empty_names(data, self.name, self.project)
      vld.validate_variables_float_values(data, self.name, self.project)
      return pd.Series(data, dtype = float)

  def _validate_existing_variables(self, data):
    """
    Проверка выполняется в методе existing_variables на каждом запросе
    значений глобальных переменных от модели REPEAT VISION 

    Parameters
    ----------
    data : dict[str, str]
      Глобальные переменные модели REPEAT VISION
    """
    if not data:
      raise err.REPEATVariableNotExistError(
        f"В модели {self.name} проекта с идентификатором {self.project} "
        "отсутствуют глобальные переменные.\n"
        "Для обеспечения работы в режиме обмена переменными между Python "
        "программой и моделью REPEAT VISION требуется наличие глобальных переменных.\n"
        "Создайте, пожалуйста, глобальные переменные в вашей модели с помощью "
        "инструмента Переменные в приложении REPEAT VISION."
        )
  
  def _validate_real_time_sync(self, real_time_sync : bool):
    """
    Проверка настройки синхронизации с реальным временем.

    Parameters
    ----------
    real_time_sync : bool
      Синхронизация с реальным временем.

    Returns
    -------
    None.

    """
    if not isinstance(real_time_sync, bool):
      raise err.REPEATValidationError(
        "Неверное значение синхронизации с реальным временем.\n"
        "Настройка синхронизации с реальным временем должна принимать значение "
        "True или False."
        )
  
  def _division_remainder(self, x : float, y : float) -> float:
    """
    Функция вычисляет остаток от деления по аналогии с операцией x % y.
    Данную функцию следует применять для вещественных значений, когда функция
    math.fmod(x, y) выдаёт некорректный результат.

    Parameters
    ----------
    x : float
      Вещественное значение делимого.
    y : float
      Вещественное значение делителя.

    Returns
    -------
    float
      Остаток от деления.

    """
    remainder = x - math.floor(x / y) * y
    return remainder
  
  def _validate_time_settings(self, real_time_sync : bool, modeling_time : int, 
                              integration_step : int, discretization_step : int):
    """
    Проверка настроек временных параметров модели. Проверка выполняется до 
    запуска модели на расчёт.

    Parameters
    ----------
    real_time_sync : bool
      Синхронизация с реальным временем.
    modeling_time : int
      Значение времени моделирования (секунды), после которого расчёт будет 
      остановлен.
    integration_step : int
      Значение шага интегрирования (миллисекунды) между соседними 
      рассчитываемыми состояниями модели.
    discretization_step : int
      Значение шага времени (миллисекунды) между ближайшими занесениями 
      результатов расчёта в базу данных.

    Returns
    -------
    None.

    """
    settings = pd.Series(
      dict(modeling_time = modeling_time, integration_step = integration_step, discretization_step = discretization_step),
      dtype = object
      )
    if real_time_sync:
      is_number_check = lambda i: isinstance(i, int)
      message_rt = "Включена синхронизация с реальным временем"
      message_valid_types = "целыми числами"
        
    else: 
      # Если нет синхронизации с реальным временем, то настройки времени
      # могут быть целыми или вещественными значениями
      is_number_check = lambda i: isinstance(i, int | float)
      message_rt = "Синхронизация с реальным временем выключена"
      message_valid_types = "целыми или вещественными числами"
    
    is_number = settings.apply(is_number_check)
    if not all(is_number):
      other_types = settings[~ is_number].to_string(dtype = False)
      raise err.REPEATValidationError(
        f"{message_rt}.\n"
        f"Все значения временных настроек должны быть {message_valid_types}.\n"
        "Необходимо исправить значения следующих настроек:\n"
        f"{other_types}"
        )
    
    is_positives = settings > 0
    # Все временные настройки должны содержать положительные значения
    if not all(is_positives):
      negatives = settings[~ is_positives].to_string(dtype = False)
      raise err.REPEATValidationError(
        "Все настройки временных параметров модели должны содержать "
        "положительные значения.\n"
        "Необходимо исправить значения следующих настроек:\n"
        f"{negatives}"
        )
    
    time_ms = modeling_time * 1000
    step_settings = settings.drop('modeling_time')
    is_steps_less_time = step_settings <= time_ms
    # Все шаги должны быть меньше времени моделирования
    if not all(is_steps_less_time):
      invalid_steps = step_settings[~ is_steps_less_time].to_string(dtype = False)
      raise err.REPEATValidationError(
        "Значения шага интегрирования и шага дискретизации должны быть меньше "
        "времени моделирования.\n"
        "Необходимо исправить значения следующих настроек:\n"
        f"{invalid_steps}"
        )
    
    # Шаг интегрирования должен быть всегда меньше или равен шагу дискретизации
    if not integration_step <= discretization_step:
      raise err.REPEATValidationError(
        "Шаг интегрирования должен быть всегда меньше или равен шагу "
        "дискретизации.\n"
        "Необходимо исправить значения следующих настроек:\n"
        f"{integration_step = }\n"
        f"{discretization_step = }"
        )
    
    # Шаг дискретизации должен быть кратным шагу интегрирования 
    if self._division_remainder(discretization_step, integration_step):
      # Если есть остаток от деления, то нет кратности
      raise err.REPEATValidationError(
        "Шаг дискретизации должен быть кратным шагу интегрирования.\n"
        "Необходимо исправить значения следующих настроек:\n"
        f"{integration_step = }\n"
        f"{discretization_step = }"
        )
  
  def _validate_time_interval(self, time_interval : TimeInterval):
    if not (time_interval is None or 
            isinstance(time_interval, TimeInterval)):
      raise err.REPEATValidationError(
        "Настройка интервала времени должна выполняться с применением класса "
        "TimeInterval"
        )
  
  @property 
  def log(self):
    """
    Атрибут журнала с описанием процесса расчёта модели

    Raises
    ------
    REPEATHTTPError
      В случае невозможности получения журнала.

    Returns
    -------
    dict
      Словарь с журналом.

    """
    try:
      response = requests.get(
        self.endpoints.log,
        auth = self.endpoints.auth,
        verify = False,
        headers = self.project_to_repeat(),  
        )
      response.raise_for_status()
      
    except HTTPError as error:
      # TODO Добавить обработку ошибок для метода log
      err.handle_unknown_errors(
        error,
        "на этапе запроса журнала процесса расчёта модели"
        ) 
      
    else:
      return response.json()    

  def get_all_parameters(self) -> dict:
    """
    Функция возвращает всю доступную информацию о параметрах блоков модели 
    REPEAT VISION

    Notes
    -----
    Метод работает **после** запуска расчёта модели методом :py:meth:`run`.

    Returns
    -------
    parameters : dict
      Словарь с параметрами модели. Ключ : str словаря parameters - 
      идентификаторы блоков модели REPEAT VISION. Значение : dict словаря parameters -
      набор параметров блока. 

    """
    try:
      response = requests.get(
        self.solver.get_all,
        auth = self.endpoints.auth,
        verify = False,
        headers = self.solver.to_header_request(),       
        )
      response.raise_for_status()
      
    except HTTPError as http_error:
      err.handle_model_info_error_codes(http_error)
      
    else:
      info =response.json()
      parameters = info['Elements']
      # Backend выдаёт строковое значение идентификатора блока в виде его 
      # номера или uuid. Значения символов от backend могут быть как строчными,
      # так и заглавными. Для единообразия и соответствия block_id с parameter_id 
      # принято решение все id приводить к заглавным символам.
      parameters = {
        key.upper() : val for key, val in parameters.items()
        }
      return parameters
  
  def project_to_repeat(self):
    return {'ProjectId' : str(self.project)}

class Model:
  """
  Класс для взаимодействия с моделью REPEAT для получения результатов расчётов
  
  .. deprecated:: 2.0.0
     Необходимо использовать класс :py:class:`ExplorationModel` для 
     взаимодействия с моделью REPEAT.
  
  Notes
  -----
  Требуется предварительный запуск на расчёт модели REPEAT и приостановка модели
  в нужный момент времени для дальнейшего анализа результатов с помощью 
  экземпляра класса Model.

  Parameters
  ----------
  user : User
    Экземпляр класса User
  solver : Solver
    Экземпляр класса Solver
  time_interval : TimeInterval
    Экземпляр класса TimeInterval

  Returns
  -------
  None

  Examples
  --------
  >>> user = User(token = 'уникальный токен из кабинета пользователя REPEAT')
  >>> app = Application(user)
  >>> t_interval = TimeInterval(start = 1, end = 2050) 
  >>> model = app.get_model(t_interval)
  >>> with model as md:
  >>>     res1 = md.get_results('1687723033287_OUT_2')
  >>>     res2 = md.get_results('1687722637724_OUT_3')
  """
  def __init__(self, user, solver : Solver, time_interval : TimeInterval):
    self.user = user 
    self.solver = solver
    self.auth = APIKeyAuth(self.user.token)
    self.time_interval = time_interval
    self.parameters = self.get_all_parameters()
    warnings.warn(
      "Класс Model является устаревшим.\n"
      "Необходимо использовать класс ExplorationModel "
      "для взаимодействия с моделью REPEAT.",
      err.REPEATDeprecationWarning,
      )
 
  def get_all_parameters(self):
    "Функция возвращает всю доступную информацию о параметрах модели REPEAT"
    try:
      response = requests.get(
        self.solver.get_all,
        auth = self.auth,
        verify = False,
        headers = self.solver.to_header_request(),       
        )
      response.raise_for_status()
      
    except HTTPError as http_error:
      err.handle_model_info_error_codes(http_error)
      
    else:
      info =response.json()
      parameters = info['Elements']
      # Backend выдаёт строковое значение идентификатора блока в виде его 
      # номера или uuid. Значения символов от backend могут быть как строчными,
      # так и заглавными. Для единообразия и соответствия block_id с parameter_id 
      # принято решение все id приводить к заглавным символам.
      parameters = {
        key.upper() : val for key, val in parameters.items()
        }
      return parameters

  def get_parameter(self, name : str) -> Parameter:
    """
    Метод возвращает параметр, существующий в модели REPEAT.

    Parameters
    ----------
    name : str
      Имя параметра. Доступное имя параметров можно посмотреть в словаре 
      parameters экземпляра класса Model

    Raises
    ------
    REPEATParameterNotExistError
      Ошибка, объявляемая, если параметр name отсутствует в наборе параметров
      модели REPEAT.

    Returns
    -------
    Parameter
      Экземпляр класса Parameter.

    """
    # Допускается копирование id параметра из интерфейса блока для остальных
    # блоков, но для данного случая необходима проверка id параметра
    # В данном случае допускается параметр только вида "1719203162182_OUT_2"
    parameter = {
      'parameter_id' : name,
      'block_id' : name.split("_")[0],
      }
    vld.validate_parameter_name_structure(name)
    check_parameter_exist(
      **parameter,
      parameters = self.parameters, 
      ) 
    return Parameter(name = name, time_interval = self.time_interval)

  def get_results(self, name : str):
    """
    Метод возвращает результаты для запрашиваемого имени параметра модели

    Parameters
    ----------
    name : str
      Имя параметра.

    Raises
    ------
    REPEATParameterNotExistError
      Ошибка, объявляемая, если параметр name отсутствует в наборе параметров
      модели REPEAT.

    Returns
    -------
    results : pd.Seris
      Временной ряд значений параметра в структуре pandas.Series. Индексы 
      Series являются значениями расчётного времени между начальным и конечным 
      значениями экземпляра класса TimeInterval

    """
    parameter = self.get_parameter(name)
    results = get_results(parameter, self.auth, self.solver)
    return results

  def __enter__(self):
    return self
  
  def __exit__(self, exc_type, exc_value, exc_tb):
    pass

@dataclass 
class Application:
  """
  Класс настройки соединения с моделью REPEAT VISION
  
  Attributes
  ----------
  projects : dict
    Набор проектов пользователя. Ключ : str | int в projects - уникальный 
    идентификатор проекта. Значение : dict в projects - описание проекта.
    
    .. versionchanged:: 2.0.0
       Изменится тип на ``pandas.Series``. В аттрибуте ``projects`` 
       ключом ``str`` станет идентификатор проекта, а значением ``str`` будет 
       имя проекта. Дополнительную информацию о проектах можно получить с 
       помощью метода :py:meth:`get_projects`

  Parameters
  ----------
  user : :py:class:`repeat.repeat_user.User`
    Экземпляр класса User с описанием параметров пользователя, необходимых для 
    авторизации и последующего использования модуля repeat
  address : str, optional
    Адрес сайта платформы REPEAT VISION. Значение по умолчанию 
    ``'https://app.repeat.vision'``. Аргументу `address` может присваиваться 
    другой адрес платформы в случае использования дистрибутива REPEAT VISION.
    
    .. versionchanged:: 1.3.0
       Значение по умолчанию аргумента `address` изменено на 
       ``'https://app.repeat.vision'``

  common_path : str
    Общая часть пути к методам REST API REPEAT VISION. Значение по умолчанию 
    ``'/backend/api/v1/public'``. Аргументу `common_path` может присваиваться 
    другой путь к методам платформы в случае использования дистрибутива 
    REPEAT VISION, например, ``common_path = '/api/v1/public'``.

  Returns
  -------
  None

  Examples
  --------
  >>> from repeat import User, Application
  >>>  
  >>> user = User(token = "уникальный токен из кабинета пользователя REPEAT VISION")
  >>> app = Application(user)
  >>> print(app.projects)
  >>> # {"21425d1a-70f9-4bke-8140-81bd312bd91b": {
  >>> #   "userId": "11125d1a-70f9-5bke-5145-81bd312ad91a",
  >>> #   "projectId": "21425d1a-70f9-4bke-8140-81bd312bd91b",
  >>> #   "role": "owner",
  >>> #   "createdAt": "2024-03-20T09:32:03.565075+03:00",
  >>> #   "updatedAt": "2024-03-20T09:32:03.565075+03:00",
  >>> #   "projectName": "[DEMO] EV",  
  
  Пример использования REPEAT VISION в дистрибутиве, установленного по 
  локальному адресу ``"https://my.repeat.vision.local"``, в котором публичный
  REST API расположен по пути ``"/api/v1/public"``
  
  >>> from repeat import User, Application
  >>> 
  >>> user = User( token = "уникальный токен из кабинета пользователя дистрибутива REPEAT VISION")
  >>> app = Application(
  >>>     user, 
  >>>     address = "https://my.repeat.vision.local",
  >>>     common_path = "/api/v1/public"
  >>>     )
  """
  user : User
  address : str = "https://app.repeat.vision"
  common_path : str = "/backend/api/v1/public"
  
  def __post_init__(self):
    vld.validate_user_api_key(_UserEndpoints(
      self.address, 
      APIKeyAuth(self.user.token),
      self.common_path
      ))
    self.endpoints = _ApplicationEndpoints(
      self.address, 
      APIKeyAuth(self.user.token),
      self.common_path
      )
    self.projects = self.get_projects()
  
  def get_projects(self, to_pandas = False, verbose = True):
    """
    Метод возвращает информацию о проектах пользователя

    .. versionadded:: 1.2.0

    Parameters
    ----------
    to_pandas : bool
      Флаг выбора структуры данных, в которой необходимо вернуть список 
      проектов. Значение по умолчанию ``False``, при котором возвращается 
      словарь.
    verbose: bool
      Флаг выбора количества свойств, помещаемых в структуру данных. 
      Значение по умолчанию ``True``, при котором сохраняются все свойства 
      каждого проекта. В случае ``False`` о каждом проекте сохраняется только 
      имя и идентификатор проекта.

    Returns
    -------
    dict[str | int, dict] | pd.Series | pd.DataFrame
      Информация о проектах. Ключ - идентификатор проекта, 
      значение - свойства о проекте REPEAT VISION

    Examples
    --------
    >>> import repeat as rp
    >>> 
    >>> user = rp.User(token = "уникальный ключ из кабинета пользователя REPEAT VISION")
    >>> app = rp.Application(user)
    >>> projects = app.get_projects(to_pandas = False, verbose = True)
    >>> print(projects)
    >>> # {"21425d1a-70f9-4bke-8140-81bd312bd91b": {
    >>> #   "userId": "11125d1a-70f9-5bke-5145-81bd312ad91a",
    >>> #   "projectId": "21425d1a-70f9-4bke-8140-81bd312bd91b",
    >>> #   "role": "owner",
    >>> #   "createdAt": "2024-03-20T09:32:03.565075+03:00",
    >>> #   "updatedAt": "2024-03-20T09:32:03.565075+03:00",
    >>> #   "projectName": "[DEMO] EV",    
    >>> project_names = app.get_projects(to_pandas = True, verbose = False)
    >>> print(project_names.head(2))
    >>> # 21425d1a-70f9-4bke-8140-81bd312bd91b                        [DEMO] EV
    >>> # bb18efd5-52b7-4d78-bk12-734653g77b45   DEMO] ТАД подъемного механизма

    """
    try:
      response = requests.get(
        self.endpoints.projects,
        verify = False,
        auth = self.endpoints.auth,
        )
      response.raise_for_status()
      
    except HTTPError as error:
      err.handle_unknown_errors(
        error,
        "на этапе получения информации о проектах"
        )
      
    else:
      info = response.json()
      if not info:
        raise err.REPEATProjectNotExistError(
          "У пользователя нет проектов в REPEAT VISION.\n"
          "Требуется создать хотя бы 1 проект."
          )
      def project_id_to_str(item : dict):
        item["projectId"] = str(item["projectId"])
        return item
      
      info = [project_id_to_str(i) for i in info]
      if not verbose: 
        # Простой набор с идентификаторами и именами проектов
        projects = {i["projectId"] : i["projectName"] for i in info}
        if to_pandas:
          projects = pd.Series(projects)
      
      else:
        #  Набор проектов с подробным описанием
        if to_pandas:
          projects = pd.DataFrame(info)
          projects.set_index("projectId", inplace = True)
          projects.insert(0, "projectName", projects.pop("projectName"))
          for column in ("createdAt", "updatedAt"):
            projects.insert(
              1, 
              column,
              pd.to_datetime(projects.pop(column))
              )
        else:
          projects = {i["projectId"] : i for i in info}
        
      return projects
  
  def _validate_project_id(self, project : str):
    if project not in self.projects:
        raise err.REPEATProjectNotExistError(
          f"Проект с идентификатором {project = } отсутствует в списке проектов.\n"
          "Проверьте, пожалуйста, номер проекта в списке ваших проектов.\n"
          "Список ваших проектов доступен на следующих ресурсах:\n"
          "на сайте https://app.repeat.vision/projects"
          )
  
  def _validate_solver_wait_settings(self, solver_retry_delay : float,
                                     max_retries_number : int
                                     ):
    
    if not isinstance(max_retries_number, int):
      raise err.REPEATValidationError(
        "Необходимо исправить значение настройки max_retries_number.\n"
        "Значение должно быть целым числом."
        )
      
    if not max_retries_number >= 0:
      raise err.REPEATValidationError(
        "Необходимо исправить значение настройки max_retries_number.\n"
        "Значение должно быть больше или равным нулю."
        )
    
    if not isinstance(solver_retry_delay, float | int):
      raise err.REPEATValidationError(
        "Необходимо исправить значение настройки solver_retry_delay.\n"
        "Значение должно быть вещественным числом."
        )
    
    if not solver_retry_delay > 0:
      raise err.REPEATValidationError(
        "Необходимо исправить значение настройки solver_retry_delay.\n"
        "Значение должно быть больше 0."
        )
  
  def get_exploration_model(self, project : str | int, 
                            time_interval : TimeInterval = None,
                            solver_retry_delay : float = 0.25,
                            max_retries_number : int = 0
                            ) -> ExplorationModel:
    """
    Метод возвращает экземпляр класса :py:class:`ExplorationModel` для 
    дальнейшего взаимодействия с моделью REPEAT VISION с обеспечением передачи 
    параметров в модель и получением результатов расчётов.

    Parameters
    ----------
    project : str | int
      Уникальный идентификатор проекта с моделью REPEAT VISION. 
      
      .. hint::
      
        Номер проекта доступен в приложении REPEAT VISION на странице 
        управления проектами https://app.repeat.vision/projects Также номер 
        проекта доступен после открытия (для редактирования или запуска) в 
        настройках проекта в поле id.
    
    time_interval : :py:class:`repeat.data_structures.TimeInterval` 
      Класс для описания интервала времени. Значение по умолчанию None.
    solver_retry_delay : float | int
      Длительность секунд для одной задержки расчёта. Значение по умолчанию 
      :math:`0.25 [cек]`. Данный параметр, а также аргумент ``max_retries_number`` 
      необходимы на следующие случаи:
      
      * Количество пользователей, которые выполняют запуск моделей на расчёт
        превышает доступное количество расчётных модулей. Тогда в расчётных 
        циклах допускается время на ожидание свободного расчётного модуля;
      * Выполнение параметрических исследований, решения задач оптимизации или
        выполнение расчётных циклов в дистрибутиве платформы REPEAT VISION в 
        локальной сети предприятия с ограниченным количеством доступных.
        расчётных модулей. Тогда возможен случай начала расчётного цикла при
        отсутствии хотя бы одного доступного расчётного модуля.
      
      .. versionadded:: 1.1.0
    
    max_retries_number : int
      Количество попыток задержки расчёта. Если значение больше нуля, то 
      выполняется проверка наличия свободного расчётного модуля. 
      Значение по умолчанию 0.
      
      .. versionadded:: 1.1.0

    Returns
    -------
    model : ExplorationModel
      Экземпляр класса :py:class:`ExplorationModel` для дальнейшего 
      взаимодействия с моделью REPEAT VISION.

    Examples
    --------
    >>> from repeat import User, Application, TimeInterval
    >>>  
    >>> user = User(token = "уникальный токен из кабинета пользователя REPEAT VISION")
    >>> app = Application(user)
    >>> t_interval = TimeInterval(start = 1, end = 2500)
    >>> project = "21425d1a-70f9-4bke-8140-81bd312bd91b"
    >>> model = app.get_exploration_model(project, t_interval)
    >>> print(model)
    >>> # ExplorationModel(project = '21425d1a-70f9-4bke-8140-81bd312bd91b', 
    >>> #                  name = 'Подготовка модели для автоматизации', 
    >>> #                  time_interval = TimeInterval(start = 0, end = 1000))
    """
    project = str(project)
    self._validate_project_id(project)
    self._validate_solver_wait_settings(solver_retry_delay, max_retries_number)
    model = ExplorationModel(
      project, 
      self.projects[project]['projectName'], 
      time_interval, 
      self.endpoints,
      solver_retry_delay, 
      max_retries_number
      ) 
      
    return model

  def get_model(self, time_interval : TimeInterval) -> Model:
    """
    Метод возвращает экземпляр класса Model для дальнейшего получения 
    результатов расчёта из модели REPEAT VISION
    
    .. deprecated:: 2.0.0
       Необходимо использовать метод :py:meth:`get_exploration_model` для
       инициализации класса :py:class:`ExplorationModel` с целью дальнейшего
       взаимодействия с моделью REPEAT VISION.

    Notes
    -----
    Требуется предварительный запуск на расчёт модели REPEAT VISION и приостановка 
    модели в нужный момент времени для дальнейшего анализа результатов 
    с помощью экземпляра класса Model.

    Parameters
    ----------
    time_interval : :py:class:`repeat.data_structures.TimeInterval` 
      Класс для описания интервала времени.

    Returns
    -------
    Model
      Экземпляр класса Model для дальнейшего получения результатов расчёта из 
      модели REPEAT VISION.

    Examples
    --------
    >>> from repeat import User, Application, TimeInterval
    >>>  
    >>> user = User(token = 'уникальный токен из кабинета пользователя REPEAT VISION')
    >>> app = Application(user)
    >>> t_interval = TimeInterval(start = 1, end = 2500)
    >>> model = app.get_model(t_interval)
    """
    solver = get_solver_address(self.address, self.endpoints.auth)
    return Model(self.user, solver, time_interval)
